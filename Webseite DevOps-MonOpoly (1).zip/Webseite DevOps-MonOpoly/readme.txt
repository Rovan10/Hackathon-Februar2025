To use the application buildt in Partyrock, please upload the m-cloud-documentation-example.html file into the widget top left. 

On the top right, enter your expertise level: Anfänger, Fortgeschrittener, Experte. 

Then ask a question in the textbox below. 

You will get a specific answer to your question. 

Example-Question: 
How can I obtain an azure key? 

Or more general - a question that Ursula from SWM could realistically ask, according to her role and knowledge:

Ich habe gesehen, dass unsere Anwendung in Azure Zugriffsschlüssel nutzt. Wie kann ich prüfen, wer darauf Zugriff hat und wie oft sie genutzt werden? Gibt es eine Möglichkeit, die Keys regelmäßig automatisch zu rotieren, um die Sicherheit zu erhöhen? Wo finde ich eine Übersicht über alle aktiven Keys, ohne dass ich jeden Dienst einzeln durchgehen muss?
